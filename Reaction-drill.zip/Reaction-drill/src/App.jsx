import React, { useState, useEffect } from "react";
import Countdown from "./components/Countdown";
import RandomWord from "./components/RandomWord";
import Finish from "./components/Finish";
import "./App.css";

const App = () => {
  const [stage, setStage] = useState("start");

  // ESCキーで強制リセット
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        setStage("start"); // スタート画面に戻す
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  return (
    <div className="app-container">
      {stage === "start" && (
        <div className="start-container">
          <button className="start-button" onClick={() => setStage("countdown")}>
            Start
          </button>
        </div>
      )}
      {stage === "countdown" && (
        <Countdown onFinish={() => setStage("random")} />
      )}
      {stage === "random" && (
        <RandomWord count={6} onFinish={() => setStage("finish")} />
      )}
      {stage === "finish" && <Finish onRestart={() => setStage("start")} />}
    </div>
  );
};

export default App;
