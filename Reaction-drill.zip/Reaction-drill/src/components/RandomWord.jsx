import React, { useState, useEffect } from "react";
import "../App.css";

const RandomWord = ({ count, onFinish }) => {
  const words = ["Go", "Pass", "→", "←"];
  const [currentWord, setCurrentWord] = useState("");
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step < count) {
      // 前回の単語を除いた候補を作成
      const candidates = words.filter((w) => w !== currentWord);

      // 候補からランダムに選ぶ
      const randomWord = candidates[Math.floor(Math.random() * candidates.length)];
      setCurrentWord(randomWord);

      const timer = setTimeout(() => {
        setStep((prev) => prev + 1);
      }, 1200);

      return () => clearTimeout(timer);
    } else {
      onFinish();
    }
  }, [step, count, onFinish]); // currentWordは依存に入れない（無限ループ防止）

  return <div className="fullscreen-text">{currentWord}</div>;
};

export default RandomWord;
