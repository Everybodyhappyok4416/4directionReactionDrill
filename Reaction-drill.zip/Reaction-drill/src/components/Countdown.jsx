import React, { useState, useEffect } from "react";
import "../App.css";

const Countdown = ({ onFinish }) => {
  const [count, setCount] = useState(3);
  const [text, setText] = useState(3);

  useEffect(() => {
    if (count >= 0) {
      const timer = setTimeout(() => {
        if (count === 0) {
          setText("Start!");
          setTimeout(onFinish, 1000); // 1秒表示して次へ
        } else {
          setText(count);
        }
        setCount((prev) => prev - 1);
      }, 1000);

      return () => clearTimeout(timer);
    }
  }, [count, onFinish]);

  return <div className="fullscreen-text">{text}</div>;
};

export default Countdown;
